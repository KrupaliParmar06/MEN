var Constants =(function () {
    function Constants() {
    }
    Constants.fullNameRegex = /^[a-zA-Z]{4,60}(?: [a-zA-Z]+){0,2}$/;
    Constants.emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    Constants.numberRegex = /^[0-9]+$/;
   
    
    return Constants;
}());

exports.Constants = Constants;
